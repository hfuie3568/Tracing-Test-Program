﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;    //C:\Users\hfuie\Desktop\3D\b.PNG
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
namespace ReadImageSample
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

    private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            // image.Source = new BitmapImage(new Uri(textBox.Text));
            
            /*Bitmap a;    Bitmap 생성
            a = new Bitmap(textBox.Text);*/
            //a=GrayScale(a);


            /*  BitmapImage 생성 및 파일 불러오기
              BitmapImage im = new BitmapImage();
              im.BeginInit();
              im.UriSource = new Uri(textBox.Text);
              im.EndInit();
              this.image.Source = im;*/


            BitmapImage firstBitmapImage = new BitmapImage();
            
            firstBitmapImage.BeginInit();
            firstBitmapImage.UriSource = new Uri(textBox.Text);  // image Source 불러옴

            firstBitmapImage.EndInit();

            firstimage.Source = firstBitmapImage;   //기존 이미지 출력

            FormatConvertedBitmap GrayChange_BitmapSource = new FormatConvertedBitmap();
            
            GrayChange_BitmapSource.BeginInit();
            
            GrayChange_BitmapSource.Source = firstBitmapImage;

            GrayChange_BitmapSource.DestinationFormat = PixelFormats.Gray32Float; //불러온 이미지 흑백 변환
            GrayChange_BitmapSource.EndInit();

            grayimage.Source = GrayChange_BitmapSource;   //흑백으로 변환된 이미지 출력

            StartButton.Visibility = Visibility;     //Start 버튼 활성화
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            Window1 start =new Window1();
            this.Close();
            start.Show();
        }
    }
}